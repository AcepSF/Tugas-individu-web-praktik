## Installation

```sh
pip install -r requirements.txt
```

## How to Run

```
export FLASK_APP=app.py
export FLASK_ENV=development
```

## Production Link

https://flaskecommerceapp.herokuapp.com
