# from flask import Blueprint, render_template, request, abort
# from app.models import Fashion, Jewelry, Bicycle, Apparel

# products_bp = Blueprint("products_bp", __name__, template_folder="templates/products")


# @products_bp.route("/apparels")
# def apparels():
#     page = int(request.args.get("page", 1))
#     per_page = 10
#     apparels = Apparel.query.paginate(page, per_page, error_out=False)
#     if apparels is None:
#         abort(404)
#     else:
#         return render_template("list.html", products=apparels, title="Apparels")


# @products_bp.route("/bicycles")
# def bicycle():
#     page = int(request.args.get("page", 1))
#     per_page = 10
#     bicycles = Bicycle.query.paginate(page, per_page, error_out=False)
#     if bicycles is None:
#         abort(404)
#     else:
#         return render_template("list.html", products=bicycles, title="Bicycle")


# @products_bp.route("/jewelry")
# def jewelry():
#     page = int(request.args.get("page", 1))
#     per_page = 10
#     jewelries = Jewelry.query.paginate(page, per_page, error_out=False)
#     if jewelries is None:
#         abort(404)
#     else:
#         return render_template("list.html", products=jewelries, title="Jewelry")


# @products_bp.route("/fashion")
# def fashion():
#     page = int(request.args.get("page", 1))
#     per_page = 10
#     fashions = Fashion.query.paginate(page, per_page, error_out=False)
#     if fashions is None:
#         abort(404)
#     else:
#         return render_template("list.html", products=fashions, title="Fashions")


# @products_bp.route("/<product>/<product_id>")
# def view_product(product, product_item):
#     product = Jewelry(product)
#     product_items = product.return_items()
#     product_items = [dict(p) for p in product.return_items()]
#     product_name = [
#         p for p in product_items if p["name"].lower() == product_item.lower()
#     ]
#     if len(product_name) == 0:
#         abort(404)
#     else:
#         return render_template(
#             "view.html",
#             results={"item": product_name, "keyword": product_item},
#             title=product_item,
#         )


# @products_bp.route("/view")
# def view():
#     id = int(request.args.get("id"))
#     product = Jewelry()
#     product_items = product.show_all_items()
#     product_items = [dict(p) for p in product_items if p["id"] == id]
#     print(product_items)
#     return render_template(
#         "view.html", results={"item": product_items}, title="Product View"
#     )


from flask import Blueprint, render_template, request, abort
from app.models import Fashion, Jewelry, Bicycle, Apparel

products_bp = Blueprint("products_bp", __name__, template_folder="templates/products")

def get_products(page, per_page, query, template_name, title):
    products = query.paginate(page, per_page, error_out=False)
    if not products.items:
        abort(404)
    else:
        return render_template(template_name, products=products, title=title)

# Rute-rute yang sudah diperbaiki
@products_bp.route("/list/apparels")
def apparels():
    page = int(request.args.get("page", 1))
    per_page = 10
    return get_products(page, per_page, Apparel.query, "list.html", "Apparels")

@products_bp.route("/list/bicycles")
def bicycle():
    page = int(request.args.get("page", 1))
    per_page = 10
    return get_products(page, per_page, Bicycle.query, "list.html", "Bicycles")

@products_bp.route("/list/jewelries")
def jewelry():
    page = int(request.args.get("page", 1))
    per_page = 10
    return get_products(page, per_page, Jewelry.query, "list.html", "Jewelries")

@products_bp.route("/list/fashions")
def fashion():
    page = int(request.args.get("page", 1))
    per_page = 10
    return get_products(page, per_page, Fashion.query, "list.html", "Fashions")

# Rute untuk menangani "page not found"
@products_bp.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404


@products_bp.route("/<product>/<product_item>")
def view_product(product, product_item):
    product_query = None

    if product.lower() == "apparel":
        product_query = Apparel
    elif product.lower() == "bicycle":
        product_query = Bicycle
    elif product.lower() == "jewelry":
        product_query = Jewelry
    elif product.lower() == "fashion":
        product_query = Fashion
    else:
        abort(404)

    product_items = product_query.query.filter_by(name=product_item).first()

    if product_items is None:
        abort(404)
    else:
        return render_template("view.html", results={"item": product_items, "keyword": product_item}, title=product_item)

@products_bp.route("/view")
def view():
    id = int(request.args.get("id"))
    product = Jewelry()  # Jika ini akan digunakan untuk semua jenis produk, mungkin Anda perlu menyesuaikan ini.
    product_items = product.show_all_items()
    product_items = [dict(p) for p in product_items if p["id"] == id]

    return render_template("view.html", results={"item": product_items}, title="Product View")
